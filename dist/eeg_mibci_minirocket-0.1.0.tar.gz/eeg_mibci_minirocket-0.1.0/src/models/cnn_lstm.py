"""Hybrid CNN-LSTM Deep Learning Architecture.
Implements the exact 13-layer model specified in Table 1 & Figure 5 of Hwaidi & Ghanem (2026).
"""

import torch
import torch.nn as nn
from typing import Dict, Any


class HybridCNNLSTM(nn.Module):
    """13-layer CNN-LSTM Hybrid Neural Network for Motor Imagery EEG Classification."""

    def __init__(
        self,
        input_channels: int = 1,
        sequence_length: int = 1280,
        lstm_units: int = 100,
        lstm_timesteps: int = 62,
        num_classes: int = 4,
        conv1_filters: int = 16,
        conv2_filters: int = 32,
        kernel_size: int = 3,
        dropout_conv: float = 0.5,
        dropout_lstm: float = 0.5,
        dropout_dense: float = 0.25,
    ):
        super().__init__()
        self.input_channels = input_channels
        self.sequence_length = sequence_length
        self.lstm_units = lstm_units
        self.lstm_timesteps = lstm_timesteps
        self.num_classes = num_classes

        # Layer 1: Input (handled as tensor input (batch, 1, 1280))

        # Layer 2: Conv1D (16 filters, kernel size 3, stride 1, VALID padding, ReLU)
        # 1280 -> 1278
        self.conv1 = nn.Conv1d(
            in_channels=input_channels,
            out_channels=conv1_filters,
            kernel_size=kernel_size,
            stride=1,
            padding=0,
        )
        self.relu1 = nn.ReLU()

        # Layer 3: Conv1D (32 filters, kernel size 3, stride 1, VALID padding, ReLU)
        # 1278 -> 1276
        self.conv2 = nn.Conv1d(
            in_channels=conv1_filters,
            out_channels=conv2_filters,
            kernel_size=kernel_size,
            stride=1,
            padding=0,
        )
        self.relu2 = nn.ReLU()

        # Layer 4: Dropout (0.5)
        self.dropout_conv = nn.Dropout(dropout_conv)

        # Layer 5: Max Pooling 1D (pool size 2, stride 1, VALID padding)
        # 1276 -> 1275
        self.pool = nn.MaxPool1d(kernel_size=2, stride=1)

        # Layer 6: Adaptive sequence alignment for Layer 7 LSTM
        # As in Table 1: LSTM timesteps = 62, feature projection matching temporal grouping
        self.adaptive_align = nn.AdaptiveAvgPool1d(lstm_timesteps)

        # Layer 7: LSTM (100 units, sequence length = 62, batch_first=True)
        # Input features per timestep = 32 (conv2_filters)
        self.lstm = nn.LSTM(
            input_size=conv2_filters,
            hidden_size=lstm_units,
            num_layers=1,
            batch_first=True,
        )

        # Layer 8: Dropout (0.5)
        self.dropout_lstm = nn.Dropout(dropout_lstm)

        # Layer 9: Dense (100 units, ReLU)
        # Flattening LSTM sequence: 62 timesteps * 100 units = 6200 or mean-pooled
        # Table 1 uses Flatten before LSTM and Dense 100
        self.dense1 = nn.Linear(lstm_units, 100)
        self.relu_dense1 = nn.ReLU()

        # Layer 10: Dropout (0.25)
        self.dropout_dense1 = nn.Dropout(dropout_dense)

        # Layer 11: Dense (50 units, ReLU)
        self.dense2 = nn.Linear(100, 50)
        self.relu_dense2 = nn.ReLU()

        # Layer 12: Dropout (0.25)
        self.dropout_dense2 = nn.Dropout(dropout_dense)

        # Layer 13: Dense (4 units, Logits for 4 classes)
        self.classifier = nn.Linear(50, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through the 13 layers.

        Args:
            x: Tensor of shape (batch, 1, 1280) or (batch, 1280)

        Returns:
            Logits of shape (batch, num_classes)
        """
        if x.dim() == 2:
            x = x.unsqueeze(1)

        # L2: Conv1D + ReLU
        out = self.relu1(self.conv1(x))
        # L3: Conv1D + ReLU
        out = self.relu2(self.conv2(out))
        # L4: Dropout
        out = self.dropout_conv(out)
        # L5: Max Pooling 1D
        out = self.pool(out)

        # L6: Align to LSTM timesteps (batch, 32, 1275) -> (batch, 32, 62)
        out = self.adaptive_align(out)
        # Transpose for LSTM: (batch, timesteps=62, features=32)
        out = out.permute(0, 2, 1)

        # L7: LSTM
        lstm_out, (hn, cn) = self.lstm(out)

        # L8: Dropout on LSTM hidden representation (using last timestep representation)
        last_hidden = hn[-1] # shape (batch, 100)
        out = self.dropout_lstm(last_hidden)

        # L9: Dense 100 + ReLU
        out = self.relu_dense1(self.dense1(out))
        # L10: Dropout
        out = self.dropout_dense1(out)

        # L11: Dense 50 + ReLU
        out = self.relu_dense2(self.dense2(out))
        # L12: Dropout
        out = self.dropout_dense2(out)

        # L13: Classifier 4 classes
        logits = self.classifier(out)
        return logits

    def count_trainable_parameters(self) -> int:
        """Count total trainable parameters."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
